#include <iostream>

extern int yyparse();

int main() {
    std::cout << "Enter expression:\n";
    yyparse();
    return 0;
}

