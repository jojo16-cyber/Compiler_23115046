
# 🧮 Expression Parser

A command-line expression parser built using **Flex** (Lex) and **Bison** (Yacc). This tool reads arithmetic expressions from user input and parses them based on a defined grammar.

---

## 📁 Project Structure

- **`main.cpp`** – Program entry point, invokes the parser.
- **`lexer.l`** – Flex file: defines token patterns for lexical analysis.
- **`parser.y`** – Bison file: defines the grammar rules for parsing expressions.
- **`Makefile`** – Automates the build process (compiling and linking).

---

## ⚙️ Requirements

- **Flex**
- **Bison**
- **C++ Compiler** (e.g., `g++`)

### 📦 Install on Ubuntu/Debian:

```bash
sudo apt update
sudo apt install flex bison g++
```

---

## 🛠️ Build Instructions

Simply run:

```bash
make
```

This will:
- Generate C++ code from the Flex (`.l`) and Bison (`.y`) files.
- Compile and link everything into an executable (`parser`).

---

## ▶️ Running the Parser

After building, run the program:

```bash
./parser
```

You will be prompted to enter an expression, which will be parsed according to the grammar rules.

---

## 🧹 Clean Up

To remove generated files:

```bash
make clean
```

---

## 📄 License

This project is released under the [MIT License](https://opensource.org/licenses/MIT).

---

Happy Parsing! 🎉
